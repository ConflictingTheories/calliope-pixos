async () => {
  await _this.spriteDialogue('avatar', ['Lets get in there!']);
};
