async (_this, menu) => {
  console.log({ msg: 'opening menu', menu, scope: _this });
  _this.isPaused = true;
};
