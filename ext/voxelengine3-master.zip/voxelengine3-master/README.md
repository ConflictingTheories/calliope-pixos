# Voxelengine3
Play a demo here: https://qake.se/demo2

## Description
Voxelengine3 is a ThreeJS WebGL voxel engine.

*The code has NOT been polished and is provided "as is". There are a lot of code that are redundant and there are tons of improvements that can be made.*

## Testing

Install nodejs and run *"cd server; nodejs server.js"*. Then point your browser to *http://localhost:8000

## Screenshot
![alt tag](https://raw.github.com/lallassu/voxelengine3/master/promo.png)

