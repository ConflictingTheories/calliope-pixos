async () => {
  await _this.moveSprite('avatar', [8, 3, 0], true);
};
