async () => {
  console.log(_this);
  await _this.playScene('strange-legend');
};
