/*                                                 *\
** ----------------------------------------------- **
**          Calliope - Pixos Game Engine   	       **
** ----------------------------------------------- **
**  Copyright (c) 2020-2025 - Kyle Derby MacInnis  **
**                                                 **
**    Any unauthorized distribution or transfer    **
**       of this work is strictly prohibited.      **
**                                                 **
**               All Rights Reserved.              **
** ----------------------------------------------- **
\*                                                 */

import Utils from '../utils/index.jsx';
import { GamePad } from '../utils/gamepad/index.jsx';
import Keyboard from '../utils/keyboard.jsx';
import Database from './database.jsx';
import Store from './store.jsx';
import Hud from './hud.jsx';
import RenderManager from './render/manager.jsx';
import ResourceManager from './resource/manager.jsx';

export default class GLEngine {
  /**
   * Core Pixos Graphics & Game Engine
   * @param {*} canvas
   * @param {*} hudcanvas
   * @param {*} mipmap
   * @param {*} gamepadcanvas
   * @param {*} fileUpload
   * @param {*} width
   * @param {*} height
   */
  constructor(canvas, hudcanvas, mipmap, gamepadcanvas, fileUpload, width, height) {
    // CANVASES
    this.canvas = canvas;
    this.hudcanvas = hudcanvas;
    this.gamepadcanvas = gamepadcanvas;
    this.mipmap = mipmap;

    // INPUTS
    this.fileUpload = fileUpload;

    // SCREEN
    this.width = width;
    this.height = height;

    // UTILITIES
    this.utils = Utils;

    // RESOURCES
    this.resourceManager = new ResourceManager(this);

    // RENDERING (Graphics, Lights, Camera)
    this.renderManager = new RenderManager(this);

    //HUD
    this.hud = new Hud(this);

    // KEYBOARD
    this.keyboard = new Keyboard(this);

    // GAMEPAD
    this.gamepad = new GamePad(this);

    // AUDIO & VOICE
    this.voice = new SpeechSynthesisUtterance();

    // DATABASE
    this.database = new Database();

    // MEMORY STORE
    this.store = new Store();

    // CUTSCENE MANAGER
    // Manages scripted cutscene sequences (transitions, waits, zone loads).
    this.cutscene = new (require('../cutscene/manager.jsx').default)(this);

    // bind
    this.screenSize = this.screenSize.bind(this);
    this.render = this.render.bind(this);
    this.init = this.init.bind(this);
    this.close = this.close.bind(this);
  }

  /**
   * Initialize a Spritz object
   * @param {*} spritz
   */
  async init(spritz) {
    const ctx = this.hudcanvas.getContext('2d');
    const gl = this.canvas.getContext('webgl2');
    const gp = this.gamepadcanvas.getContext('2d');

    if (!gl) {
      throw new Error('WebGL : unable to initialize');
    }
    if (!ctx) {
      throw new Error('Canvas : unable to initialize HUD');
    }
    if (!gp) {
      throw new Error('Gamepad : unable to initialize Mobile Canvas');
    }

    // make HUD same size as canvas
    ctx.canvas.width = gl.canvas.clientWidth;
    ctx.canvas.height = gl.canvas.clientHeight;

    this.gl = gl;
    this.ctx = ctx;
    this.gp = gp;
    this.frameCount = 0;


    this.spritz = spritz;
    this.fullscreen = false;

    // initial time
    this.time = new Date().getTime();

    // init keyboard
    this.keyboard.init();

    // initialize hud
    this.hud.init();

    // initialize render manager
    this.renderManager.init();

    // Configure Gamepad & touch
    this.gamepad.init();
    this.touch = this.gamepad.listen.bind(this.gamepad);

    // Initialize Spritz
    await spritz.init(this);

    // Create and configure a debug overlay. This overlay displays
    // performance information such as FPS and draw counts and is toggled
    // using the F3 key. It is appended to the document body once the
    // engine has been initialized and the DOM is available. The overlay
    // remains hidden until toggled.
    (() => {
      const div = document.createElement('div');
      div.style.position = 'absolute';
      div.style.top = '0';
      div.style.left = '0';
      div.style.background = 'rgba(0, 0, 0, 0.6)';
      div.style.color = '#0f0';
      div.style.padding = '4px';
      div.style.fontFamily = 'monospace';
      div.style.fontSize = '12px';
      div.style.zIndex = '10000';
      div.style.pointerEvents = 'none';
      div.style.display = 'none';
      this.debugDiv = div;
      document.body.appendChild(div);
      window.addEventListener('keydown', (e) => {
        if (e.key === 'F3') {
          this.showDebug = !this.showDebug;
          this.debugDiv.style.display = this.showDebug ? 'block' : 'none';
        }
      });
    })();
  }

  /**
   * Render Frame
   */
  render() {
    this.frameCount++;
    // Reset debug counters at the start of each frame so that metrics
    // reflect only the current frame's draw calls.
    if (this.renderManager && this.renderManager.resetDebugCounters) {
      this.renderManager.resetDebugCounters();
    }

    // clear canvases
    this.hud.clearHud();
    this.renderManager.clearScreen(); // todo - move into view

    const timestamp = new Date().getTime();

    // enable picker shader (Todo - Improve performance - make it only 1x1 pixel framebuffer - and avoid needing to reclear screen)
    this.renderManager.activatePickerShaderProgram(false);
    this.spritz.render(this, timestamp);
    this.getSelectedObject();

    // core render loop
    this.renderManager.clearScreen(); // todo - move into view
    this.renderManager.activateShaderProgram();
    this.gamepad.render();
    this.spritz.render(this, timestamp);
    // Update any active screen transition effect. This will draw an overlay on
    // top of the current frame when a transition is in progress. Note that
    // the RenderManager manages its own `isTransitioning` flag.
    this.renderManager.updateTransition();

    // Update cutscene manager. While a cutscene is active this will process
    // queued steps such as waits, transitions and zone loads. It runs
    // independently of the game loop and does not block rendering.
    if (this.cutscene) {
      this.cutscene.update();
    }

    // Update debug overlay if enabled. Calculate frames per second based on
    // the elapsed time since the last frame and display the number of tiles
    // and sprites drawn as well as WebGL renderer information. The overlay
    // is toggled by pressing F3.
    if (this.showDebug && this.debugDiv) {
      const now = (typeof performance !== 'undefined' ? performance.now() : Date.now());
      const delta = now - this.lastDebugTime;
      const fps = delta > 0 ? (1000.0 / delta).toFixed(1) : '0';
      this.lastDebugTime = now;
      const gl = this.gl;
      let renderer = '';
      let vendor = '';
      let version = '';
      if (gl) {
        try {
          renderer = gl.getParameter(gl.RENDERER);
          vendor = gl.getParameter(gl.VENDOR);
          version = gl.getParameter(gl.VERSION);
        } catch (e) {
          // WebGL context may be lost or parameters unavailable
        }
      }
      const debug = this.renderManager.debug || {};
      this.debugDiv.innerHTML =
        'FPS: ' + fps + '<br>' +
        'Tiles Drawn: ' + (debug.tilesDrawn || 0) + '<br>' +
        'Sprites Drawn: ' + (debug.spritesDrawn || 0) + '<br>' +
        'Objects Drawn: ' + (debug.objectsDrawn || 0) + '<br>' +
        'Renderer: ' + renderer + '<br>' +
        'Vendor: ' + vendor + '<br>' +
        'GL Version: ' + version;
    }

    this.requestId = requestAnimationFrame(this.render);
  }

  /**
   * Clear Render Loop
   */
  close() {
    cancelAnimationFrame(this.requestId);
  }

  /**
   * Get Selected Object on screen
   */
  getSelectedObject(type = 'sprite|object|tile', useFrustum = false) {
    if (this.spritz.world?.spriteList?.length <= 0) {
      return;
    }
    const gl = this.gl;
    const data = new Uint8Array(4);
    const mouseX = this.gamepad.x || 0;
    const mouseY = this.gamepad.y || 0;
    const pixelX = useFrustum ? 0 : (mouseX * gl.canvas.width) / gl.canvas.clientWidth;
    const pixelY = useFrustum ? 0 : gl.canvas.height - (mouseY * gl.canvas.height) / gl.canvas.clientHeight - 1;

    gl.readPixels(
      pixelX, // x
      pixelY, // y
      1, // width
      1, // height
      gl.RGBA, // format
      gl.UNSIGNED_BYTE, // type
      data
    ); // typed array to hold result

    let id = data[0] + (data[1] << 8) + (data[2] << 16); //+ (data[3] << 24);

    // select type(s) based on request
    type.split('|').forEach((t) => {
      switch (t) {
        case 'sprite':
          if (this.gamepad.touches['desktop'].leftClick) {
            // todo - add a new trigger method onSelect()
            // set each sprite selected
            this.spritz.world.spriteList = this.spritz.world.spriteList.map((sprite) => {
              if (sprite.objId === id) {
                sprite.isSelected = true;
                this.spritz.world.spriteDict[sprite.id].isSelected = true;
                this.spritz.world.spriteDict[sprite.id].onSelect(sprite.zone, sprite);
                // this.spritz.world.spriteDict[sprite.id].interact(this.spritz.world.spriteDict['avatar'], () => console.log('selection'));
              }
              return sprite;
            });
          }
          break;
        case 'object':
          if (this.gamepad.touches['desktop'].leftClick) {
            // todo - add a new trigger method onSelect()
            // set each object selected
            this.spritz.world.objectList = this.spritz.world.objectList.map((obj) => {
              if (obj.objId === id) {
                obj.isSelected = true;
                this.spritz.world.objectDict[obj.id].isSelected = true;
                // this.spritz.world.objectDict[sprite.id].interact(this.spritz.world.spriteDict['avatar'], () => console.log('selection'));
              }
              return obj;
            });
          }
          break;
        case 'tile':
          if (this.gamepad.touches['desktop'].leftClick) {
            // read in zone, tile, and cell data from pixel
            let zoneObjId = data[0];
            let row = data[1];
            let cell = data[2];

            // search zones and file selected tile
            this.spritz.world.zoneList.forEach((zone) => {
              if (zone.objId === zoneObjId) {
                zone.onSelect(row, cell);
              }
            });

            console.log('TODO - TILE SELECTION');
            console.log({ zoneObjId, row, cell, zones: this.spritz.world.zoneList });
          }
          break;
      }
    });

    return id;
  }

  /**
   * Greeting Text
   * @param {string} text
   */
  setGreeting(text) {
    console.log('setting GREETING');
    this.globalStore.greeting = text;
  }

  /**
   * Text to Speech output
   * @param {string} text
   * @param {SpeechSynthesisVoice} voice
   * @param {string} lang
   * @param {number} rate
   * @param {number} volume
   * @param {number} pitch
   */
  speechSynthesis(text, voice = null, lang = 'en', rate = null, volume = null, pitch = null) {
    let speech = this.voice;
    let voices = window.speechSynthesis.getVoices() ?? [];
    // set voice
    speech.voice = voices[0];
    if (rate) speech.rate = rate;
    if (volume) speech.volume = volume;
    if (pitch) speech.pitch = pitch;
    speech.text = text;
    speech.lang = lang;
    // speak
    window.speechSynthesis.speak(speech);
  }

  /**
   * convert a stream to a video
   * @param {*} stream
   * @param {*} ref
   * @returns
   */
  streamToVideo(stream, ref) {
    let video = document.createElement('video');
    if (ref) {
      video = ref.current;
    }
    video.srcObject = stream;
    video.style.width = stream.width;
    video.style.height = stream.height;
    video.play();
    return video;
  }

  /**
   * convert a stream to an image
   * @param {*} stream
   * @param {*} ref
   * @returns
   */
  streamToImage(stream, ref) {
    let video = document.createElement('video');
    if (ref) {
      video = ref.current;
    }
    video.srcObject = stream;
    video.style.width = stream.width;
    video.style.height = stream.height;
    video.play();
    return video;
  }

  /**
   * convert a stream to a texture
   * @param {*} stream
   * @param {*} ref
   * @returns
   */
  streamToTexture(stream, ref) {
    let video = document.createElement('video');
    if (ref) {
      video = ref.current;
    }
    video.srcObject = stream;
    video.style.width = stream.width;
    video.style.height = stream.height;
    video.play();
    return video;
  }

  /**
   * Screensize
   * @returns
   */
  screenSize() {
    return {
      width: this.canvas.clientWidth,
      height: this.canvas.clientHeight,
    };
  }
}
