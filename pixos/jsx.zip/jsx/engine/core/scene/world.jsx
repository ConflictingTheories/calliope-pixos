/*                                                 *\
** ----------------------------------------------- **
**          Calliope - Pixos Game Engine   	       **
** ----------------------------------------------- **
**  Copyright (c) 2020-2025 - Kyle Derby MacInnis  **
**                                                 **
**    Any unauthorized distribution or transfer    **
**       of this work is strictly prohibited.      **
**                                                 **
**               All Rights Reserved.              **
** ----------------------------------------------- **
\*                                                 */

import Zone from './zone.jsx';
import ActionQueue from '../queue/index.jsx';
import { Direction } from '@Engine/utils/enums.jsx';
import { EventLoader } from '@Engine/utils/loaders/index.jsx';

export default class World {
  constructor(engine, id) {
    this.id = id;
    this.objId = Math.round(Math.random() * 1000) + 1;
    this.engine = engine;
    this.zoneDict = {};
    this.zoneList = [];
    this.spriteDict = {};
    this.spriteList = [];
    this.objectDict = {};
    this.objectList = [];
    this.tilesetDict = {};
    this.tilesetList = [];
    this.eventList = [];
    this.eventDict = {};
    this.lastKey = new Date().getTime();
    // Track the last time a zone transition ran. This timestamp is used to
    // avoid back-to-back transitions when multiple zone loads are invoked
    // within a short period (for example, when a Lua script immediately
    // loads a zone after another zone has just been loaded). See
    // loadZone() and loadZoneFromZip() for usage.
    this.lastZoneTransitionTime = 0;
    this.isPaused = true;
    this.afterTickActions = new ActionQueue();
    this.sortZones = this.sortZones.bind(this);
    this.getZoneById = this.getZoneById.bind(this);
    this.canWalk = this.canWalk.bind(this);
    this.pathFind = this.pathFind.bind(this);
    this.menuConfig = {
      start: {
        onOpen: (menu) => {
          // auto-close - do nothing
          menu.completed = true;
        },
      },
    };
  }

  /**
   * push action into next frame
   * @param {*} action
   */
  runAfterTick(action) {
    this.afterTickActions.add(action);
  }

  /**
   * Sort zones for correct render order
   */
  sortZones() {
    this.zoneList.sort((a, b) => a.bounds[1] - b.bounds[1]);
  }

  /**
   * Fetch and Load Zone
   * @param {string} zoneId
   * @param {Zip} zip
   * @param {*} skipCache
   * @returns
   */
  async loadZoneFromZip(zoneId, zip, skipCache = false, transitionParams = { effect: 'cross', duration: 500 }) {
    // check cache ?
    if (!skipCache && this.zoneDict[zoneId]) return this.zoneDict[zoneId];
    // Perform a transition when loading zones from a zip. Unless
    // transitionParams is explicitly set to null, we fade out before
    // loading and fade back in after the new zone is ready. The caller can
    // override the effect or duration via transitionParams.
    const engine = this.engine;
    // Determine whether to perform a transition. We check that transitions
    // have been requested, that a render manager exists and that the last
    // transition finished sufficiently long ago. Without this guard, two
    // zone loads invoked in rapid succession (e.g. from a Lua script and
    // a changezone action) would trigger two separate fade sequences.
    let useTransition = false;
    if (transitionParams && engine?.renderManager) {
      const rm = engine.renderManager;
      const now = (typeof performance !== 'undefined' ? performance.now() : Date.now());
      // Compute time since the last transition started. We allow a small
      // grace period after a transition completes before a new one is
      // permitted. If a transition is still running (isTransitioning),
      // startTransition() will queue the next transition automatically.
      const timeSinceLast = now - (rm.transitionStartTime + rm.transitionDuration);
      if (!rm.isTransitioning && timeSinceLast > 100) {
        useTransition = true;
      }
    }
    if (useTransition) {
      const { effect = 'cross', duration = 500 } = transitionParams;
      await engine.renderManager.startTransition({ effect: effect, direction: 'out', duration: duration });
    }

    console.log('Loading Zone from Zip:', zoneId);

    let zoneJson = JSON.parse(await zip.file('maps/' + zoneId + '/map.json').async('string')); // main map file (/zip/maps/{zoneId}/map.json)
    let cellJson = JSON.parse(await zip.file('maps/' + zoneId + '/cells.json').async('string')); // cells (/zip/maps/{zoneId}/cells.json)

    // Fetch Zone Remotely (allows for custom maps - with approved sprites / actions)
    let z = new Zone(zoneId, this);
    await z.loadZoneFromZip(zoneJson, cellJson, zip);

    // audio
    this.zoneList.map((x) => {
      if (x.audio) {
        x.audio.pauseAudio();
      }
    });
    if (z.audio) {
      console.log(z.audio);
      z.audio.playAudio();
    }
    // add zone
    this.zoneDict[zoneId] = z;
    this.zoneList.push(z);

    // Sort for correct render order
    z.runWhenLoaded(this.sortZones);
    // fade back in once the new zone has finished loading
    if (useTransition) {
      const { effect = 'cross', duration = 500 } = transitionParams;
      await engine.renderManager.startTransition({ effect: effect, direction: 'in', duration: duration });
    }
    return z;
  }

  /**
   * Fetch and Load Zone
   * @param {string} zoneId
   * @param {boolean} remotely
   * @param {boolean} skipCache
   * @returns
   */
  async loadZone(zoneId, remotely = false, skipCache = false, transitionParams = { effect: 'cross', duration: 500 }) {
    if (!skipCache && this.zoneDict[zoneId]) return this.zoneDict[zoneId];
    // Optionally perform a transition before loading a standard zone. If a
    // transition configuration is provided, we fade out before loading and
    // fade back in after the new zone is ready. The transitionParams object
    // can specify an effect ("fade", "cross", "swirl") and duration in
    // milliseconds. The direction is automatically set to "out" and then
    // "in" for the two phases. Note: changezone actions manage their own
    // transitions and therefore should pass `null` for this parameter.
    const engine = this.engine;
    // Decide whether to perform a transition. We only start a new
    // transition if the previous one has completed and a small delay has
    // elapsed. Otherwise the new transition will be queued by
    // startTransition() if one is in progress.
    let useTransition = false;
    if (transitionParams && engine?.renderManager) {
      const rm = engine.renderManager;
      const now = (typeof performance !== 'undefined' ? performance.now() : Date.now());
      const timeSinceLast = now - (rm.transitionStartTime + rm.transitionDuration);
      if (!rm.isTransitioning && timeSinceLast > 100) {
        useTransition = true;
      }
    }
    if (useTransition) {
      const { effect = 'cross', duration = 500 } = transitionParams;
      await engine.renderManager.startTransition({ effect: effect, direction: 'out', duration: duration });
    }
    // Fetch Zone Remotely (allows for custom maps - with approved sprites / actions)
    let z = new Zone(zoneId, this);
    if (remotely) await z.loadRemote();
    else await z.load();
    // audio
    this.zoneList.map((x) => {
      if (x.audio) {
        x.audio.pauseAudio();
      }
    });
    if (z.audio) {
      console.log(z.audio);
      z.audio.playAudio();
    }
    // add zone
    this.zoneDict[zoneId] = z;
    this.zoneList.push(z);
    // Sort for correct render order
    z.runWhenLoaded(this.sortZones);
    // fade back in once the new zone has finished loading
    if (useTransition) {
      const { effect = 'cross', duration = 500 } = transitionParams;
      await engine.renderManager.startTransition({ effect: effect, direction: 'in', duration: duration });
    }
    return z;
  }

  /**
   * Remove Zone
   * @param {string} zoneId
   */
  removeZone(zoneId) {
    this.zoneList = this.zoneList.filter((zone) => {
      if (zone.id !== zoneId) {
        return true;
      } else {
        if (zone.audio) {
          zone.audio.pauseAudio();
        }
        zone.removeAllSprites();
        zone.runWhenDeleted();
      }
    });
    delete this.zoneDict[zoneId];
  }

  /**
   * Remove Zones
   */
  removeAllZones() {
    this.zoneList.map((z) => {
      if (z.audio) {
        z.audio.pauseAudio();
      }
      z.removeAllSprites();
      z.runWhenDeleted();
    });
    this.zoneList = [];
    this.zoneDict = {};
  }

  /**
   * Update
   * @param {number} time
   */
  tick(time) {
    for (let z in this.zoneDict) this.zoneDict[z]?.tick(time, this.isPaused);
    this.afterTickActions.run(time);
  }

  /**
   * read input (HIGHEST LEVEL)
   * @param {number} time
   */
  checkInput(time) {
    if (time > this.lastKey + 200) {
      let touchmap = this.engine.gamepad.checkInput();
      this.lastKey = time;
      // start
      if (this.engine.gamepad.keyPressed('start')) {
        touchmap['start'] = 0;
      }
      // select
      if (this.engine.gamepad.keyPressed('select')) {
        touchmap['select'] = 0;
        this.engine.toggleFullscreen();
      }
    }
  }

  /**
   * open start menu
   * @param {*} menuConfig
   * @param {string[]} defaultMenus
   */
  startMenu(menuConfig, defaultMenus = ['start']) {
    this.addEvent(
      new EventLoader(this.engine, 'menu', [menuConfig ?? this.menuConfig, defaultMenus, false, { autoclose: false, closeOnEnter: true }], this)
    );
  }

  /**
   * Add Event to Queue
   * @param {*} event
   */
  addEvent(event) {
    if (this.eventDict[event.id]) this.removeAction(event.id);
    this.eventDict[event.id] = event;
    this.eventList.push(event);
  }

  /**
   * Remove Action
   * @param {string} id
   */
  removeAction(id) {
    this.eventList = this.eventList.filter((event) => event.id !== id);
    delete this.eventDict[id];
  }

  /**
   * Remove All Actions
   */
  removeAllActions() {
    this.eventList = [];
    this.eventDict = {};
  }

  /**
   * Outer Tick Handler - run events, actions and ticks for zones
   * @param {number} time
   */
  tickOuter(time) {
    // read input
    this.checkInput(time);
    // Sort activities by increasing startTime, then by id
    this.eventList.sort((a, b) => {
      let dt = a.startTime - b.startTime;
      if (!dt) return dt;
      return a.id > b.id ? 1 : -1;
    });
    // Run & Queue for Removal when complete
    let toRemove = [];
    this.eventList.forEach((event) => {
      if (!event.loaded || event.startTime > time || (event.pausable && this.isPaused)) return;
      if (event.tick(time)) {
        toRemove.push(event); // remove from backlog
        event.onComplete(); // call completion handler
      }
    });
    // clear completed activities
    toRemove.forEach((event) => this.removeAction(event.id));
    // tick
    if (this.tick && !this.isPaused) this.tick(time);
  }

  /**
   * Draw Each Zone
   */
  draw() {
    for (let z in this.zoneDict) this.zoneDict[z].draw(this.engine);
  }

  /**
   * Check for Cell inclusion
   * @param {number} x
   * @param {number} y
   * @returns
   */
  zoneContaining(x, y) {
    for (let z in this.zoneDict) {
      let zone = this.zoneDict[z];
      if (zone.loaded && zone.isInZone(x, y)) return zone;
    }
    return null;
  }

  /**
   * Finds a path if one exists between two points on the world
   * @param {Vector} from
   * @param {Vector} to
   * @returns
   */
  pathFind(from, to) {
    // memory
    let steps = [],
      visited = [],
      found = false,
      world = this,
      x = from[0],
      y = from[1];
    // loop through tiles
    function buildPath(neighbour, path) {
      let jsonNeighbour = JSON.stringify([neighbour[0], neighbour[1]]);
      if (found) return false; // ignore anything further
      if (neighbour[0] == to[0] && neighbour[1] == to[1]) {
        // found it
        found = true;
        // if final location is blocked, stop in front
        if (!world.canWalk(neighbour, jsonNeighbour, visited)) {
          return [found, [...path]];
        }
        // otherwise return whole path
        return [found, [...path, to]];
      }
      // Check walkability
      if (!world.canWalk(neighbour, jsonNeighbour, visited)) return false;
      // Visit Node & continue Search
      visited.push(jsonNeighbour);
      return world
        .getNeighbours(...neighbour)
        .sort((a, b) => Math.min(Math.abs(to[0] - a[0]) - Math.abs(to[0] - b[0]), Math.abs(to[1] - a[1]) - Math.abs(to[1] - b[1])))
        .map((neigh) => buildPath(neigh, [...path, [neighbour[0], neighbour[1], 600]]))
        .filter((x) => x)
        .flat();
    }
    // Fetch Steps
    steps = world
      .getNeighbours(x, y)
      .sort((a, b) => Math.min(Math.abs(to[0] - a[0]) - Math.abs(to[0] - b[0]), Math.abs(to[1] - a[1]) - Math.abs(to[1] - b[1])))
      .map((neighbour) => buildPath(neighbour, [[from[0], from[1], 600]]))
      .filter((x) => x[0]);
    // Flatten Path from Segments
    return steps.flat();
  }

  /**
   * Get Zone by ID
   * @param {string} id
   * @returns
   */
  getZoneById(id) {
    return this.zoneDict[id];
  }

  /**
   *  Gets adjacencies
   * @param {int} x
   * @param {int} y
   * @returns
   */
  getNeighbours(x, y) {
    let top = [x, y + 1, Direction.Up],
      bottom = [x, y - 1, Direction.Down],
      left = [x - 1, y, Direction.Left],
      right = [x + 1, y, Direction.Right];
    return [top, left, right, bottom];
  }

  /**
   * Should we skip?
   * @param {*} neighbour
   * @param {*} jsonNeighbour
   * @param {*} visited
   * @returns
   */
  canWalk(neighbour, jsonNeighbour, visited) {
    let zone = this.zoneContaining(...neighbour);
    if (
      visited.indexOf(jsonNeighbour) >= 0 ||
      !zone ||
      !zone.isWalkable(...neighbour) ||
      !zone.isWalkable(neighbour[0], neighbour[1], Direction.reverse(neighbour[2]))
    ) {
      return false;
    }
    return true;
  }
}

// Pathfinding Algorithm (Note: Needs some work -- has some issues, and is not efficient)
// ---------------------
// Start Point
// Goal

// Path []
// Current Point

// --- Func
//
// Get Neighbours - Foreach Neighbour
//  - Check Neighbour
//    - Check Goal
//        - Found it - Return Path
//        - Else
//          - Get Neighbours

// ----

// GetNeighbours (x, y){
//    results = []
//    top = (x,y+1)
//    bottom = (x,y-1)
//    left = (x-1,y)
//    right = (x+1,y)
//
//    for each above
//      if (isWalkable()) add to results
//
//    return results
// }

// ----
